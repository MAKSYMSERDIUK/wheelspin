let close = document.getElementById('modalBonus-close');
let modalBonusVictory = document.getElementById('modalBonus-victory');
let count = 1;

$('html').on('click','.wheel',function () {
    if(count === 1) {
        $('.inside').addClass('variant-1');
         count++;
        setTimeout(function () {
            modalBonusVictory.style.display = "block";
            $('.inside').removeClass('variant-1');
        }, 4000);
    } 
    
});

$('html').on('click','.play',function () {
    if(count === 1) {
        $('.inside').addClass('variant-1');
         count++;
        setTimeout(function () {
            modalBonusVictory.style.display = "block";
            $('.inside').removeClass('variant-1');
        }, 4000);
    } 
    
});

$('html').on('click','.modalBonus-close',function () {
   count = 1;
   modalBonusVictory.style.display = "none";
});

